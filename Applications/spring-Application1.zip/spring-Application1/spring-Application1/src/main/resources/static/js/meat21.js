
function loader(){
    document.querySelector('.model-container').classList.add('fade-out');

}
function fadeout(){
    setInterval(loader,4000);
}
window.onload = fadeout;

function loader(){
    document.querySelector('.model-container').classList.add('fade-out');

}
function fadeout(){
    setInterval(loader,3000);
}
window.onload = fadeout;
function loader(){
    document.querySelector('.loader-container').classList.add('fade-out');

}
function fadeout(){
    setInterval(loader,4000);
}
window.onload = fadeout;

function loader(){
    document.querySelector('.loader-container').classList.add('fade-out');

}
function fadeout(){
    setInterval(loader,3000);
}
window.onload = fadeout;

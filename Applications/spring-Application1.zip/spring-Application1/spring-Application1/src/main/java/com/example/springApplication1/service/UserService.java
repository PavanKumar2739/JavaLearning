package com.example.springApplication1.service;

import com.example.springApplication1.payloadDTO.UserDetailsDto;
import com.example.springApplication1.payloadDTO.UserDto;

public interface UserService {

	public UserDto createUser(UserDto userDto);
	
	
}

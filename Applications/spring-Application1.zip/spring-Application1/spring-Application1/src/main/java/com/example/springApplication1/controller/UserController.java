package com.example.springApplication1.controller;

public class UserController {

	
}
